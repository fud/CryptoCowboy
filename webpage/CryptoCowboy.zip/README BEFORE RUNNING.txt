Hello, thanks for downloading CryptoCowboy!

Some things you need to do before running your application:

�	Have an XRP wallet with a minimum of 50 XRP or more if you have multiple trust lines enabled.

�	Have USD in your wallet as well. You need to know which Gateway hosts your USD. I have included the USD address for both Gatehub and Bitstamp, but if yours if from another gateway, you'll need to get the counterparty ID for that gateway. If you need help finding it, contact me and I will help. You will need to update the currencyCode.txt file with that information.

�	Calculate what your FixedPoint is and what your ReserveMultiplier is then modify fixedPoint.txt and reserveMultiplier.txt in the data folder to reflect this number.
	�	FixedPoint is the number of XRP you have times the price of XRP (It doesn't need to be exact, but try to make it close)
	�	ReserveMultiplier is the amount of USD you have divided by the FixedPoint (It doesn't need to be exact, but try to make it close)

�	Obtain your wallet address and secret key and update the the address.txt and secret.txt files in the config folder with that information

�	Make sure you have a trustline open for whatever currency you are trading with. You can do this with Toast Wallet.

�	I monitize this application by taking donations from the profits that you earn with this bot. Please note, many exchanges charge a percentage on the amount you are trading. The donation percentage in this bot only charges a percent on 'profits' so for example, if you make a trade for $20 and you earned 2% on that trade, I only take a percentage on the $0.40 profit you make, not the entire $20. I only make money when you make money. You may modify the donationPercent.txt file in the config folder to select your own donation amount. You may select any number between 0% and 10%. By default, it's set to 1%